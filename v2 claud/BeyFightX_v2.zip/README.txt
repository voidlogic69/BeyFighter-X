BEY FIGHT X v2 - Stadium Arena
RUN: double-click index.html (Chrome/Edge/Firefox desktop). Internet needed once for three.js (CDN).
If blocked: run `python -m http.server 8000` in this folder and open http://localhost:8000
Keep the models/ folder next to index.html.

CONTROLS  P1: WASD move, J light, K heavy, L guard, Space special
          P2: Arrows move, , light, . heavy, / guard, Enter special
FLOW: Menu -> pick bey -> spend 12 stat points (Attack/Defense/Stamina) + colour -> fight. Up to 4 rounds, first to 3 wins.
FINISHES (priority Extreme > Over > Burst > K.O. > Spin; only one can trigger, then the battle locks):
 EXTREME: ride the glowing rail (hit it at speed), launch with an attack key; meter>=50 + hit = Extreme Finish.
 OVER: get knocked through the blue exit gaps (sides). K.O.: knocked into the red pockets (ends).
 BURST: burst-resistance bar (red) hits 0 -> bey splits into blade/ratchet/tip 3D parts. SPIN: spin bar 0 / timeout.
